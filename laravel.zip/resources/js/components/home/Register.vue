<template>

</template>
<script type="text/javascript">
export default{
  data () {
    return {
      name:data
    };
  }
}
</script>
<style type="text/css">
  
</style>