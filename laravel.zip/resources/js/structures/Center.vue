<template>
  <!-- start conteiner -->
  <v-content>
      <v-container class="fill-height">
        <v-row
          justify="center"
          align="center"
        >
            <slot></slot>
        </v-row>
      </v-container>
    </v-content>
  <!-- end conteiner -->
</template>