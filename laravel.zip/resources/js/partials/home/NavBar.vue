<template>
  <div>
    <v-app-bar
      color="#E24E42"
      dark
    >
      <v-toolbar-title>ZONA EDUCATIVA</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn>

      
    </v-app-bar>
  </div>
</template>

<!--       src="images/articulos/vibrante vintage.png" -->
