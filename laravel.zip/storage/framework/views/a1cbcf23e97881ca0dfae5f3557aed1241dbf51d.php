<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>ZEG</title>

        <!-- Fonts -->
        <link rel="icon" type="image/png" href="images/icons/zeg.png" sizes="32x32">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
        <link rel="stylesheet" href="animate.min.css">
        <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <?php if(auth()->guard()->check()): ?>
            <div class="alert alert-success red">
                Has iniciado session con el correo: <?php echo e(session('email')); ?>

            </div>
        <?php endif; ?>
        <div id="app"></div>
        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/vilo0812/Projects/zonaeducativa/resources/views/app.blade.php ENDPATH**/ ?>