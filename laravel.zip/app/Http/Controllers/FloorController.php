<?php

namespace App\Http\Controllers;

use App\Floor;
use App\Handling_floor;
use App\Zone;
use Illuminate\Http\Request;

class FloorController extends Controller
{

}
