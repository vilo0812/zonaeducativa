<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Handling_ticket extends Model
{
    //
}
